const dynamoose = require("dynamoose");

const peopleSchema = new dynamoose.Schema({
  id: 'String',
  Name: "String",
  Phone: "String"
})

const peopleModel = dynamoose.model("People", peopleSchema);


exports.handler = async (event) => {
  // TODO implement
  console.log(event);

  const peopleData = await peopleModel.query().exec();

  const response = {
    statusCode: 200,
    body: JSON.stringify('peopleData::', peopleData),
  };
  return response;
};

